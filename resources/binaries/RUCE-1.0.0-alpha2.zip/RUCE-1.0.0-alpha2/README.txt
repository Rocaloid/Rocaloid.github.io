RUCE 1.0.0-alpha1 win32构建
源代码位于https://github.com/Rocaloid
www.rocaloid.org

如何安装：

1. 将所有dll文件复制到 Windows\System32\下。
2. 将RUCE.exe复制到UTAU安装目录下。
3. 设定你的UTAU工程使用的resampler为RUCE.exe。

======ENGLISH======

RUCE 1.0.0-alpha1 built for win32.
Source codes are available at https://github.com/Rocaloid
www.rocaloid.org

How to install:

1. Copy all dlls into Windows\System32\.
2. Copy RUCE.exe into UTAU's directory.
3. Set the resampler of your UTAU project to RUCE.exe.

