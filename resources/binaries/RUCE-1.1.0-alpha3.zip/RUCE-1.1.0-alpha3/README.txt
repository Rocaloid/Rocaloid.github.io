RUCE 1.1.0-alpha3 win32构建
源代码位于https://github.com/Rocaloid
www.rocaloid.org

如何安装：

1. 将所有dll文件复制到 Windows\System32\下。
2. 将RUCE_CLI.exe复制到UTAU安装目录下。
3. 设定你的UTAU工程使用的resampler为RUCE_CLI.exe。

使用说明请见http://www.rocaloid.org/blog/zh/10/11/RUCE-alpha-3-Release.html。

